package com.Exponent.BankApplication.serviceImpl;

import java.util.Iterator;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.Exponent.BankApplication.Model.Account;
import com.Exponent.BankApplication.service.RBI;
import com.Exponent.BankApplication.service.Validation;

public class SBI implements RBI {

	static Scanner sc = new Scanner(System.in);
	public static Account a = new Account();
	Account a1[] = new Account[5];

	@Override
	public void Create_Account() {

		System.out.println("How Many Accounts You Want to Add:-");
		int n = sc.nextInt();

		for (int i = 0; i < n; i++) {
			Account a2 = new Account();
			System.out.println("Enter Your Account Number");
			a2.setAccount_No(Validation.Validate_Acc_No());
			// Validation.Validate_Acc_No();
			// System.out.println("Enter your Name");
			a2.setAccount_Name(Validation.Validate_Acc_Name());
			// Validation.ValidateAccName();
			// a.setAccount_Name(sc.next());
			// System.out.println("Enter Aadhar Card Number");
			a2.setAadhar_Card(Validation.Validate_Aadhar_Card());
			// System.out.println("Enter Pancard Number");
			a2.setPancard(Validation.Validate_Pan_Card());
			// System.out.println("Enter Your Contact Number");
			a2.setContact(Validation.Validation_Of_Contact());
			// System.out.println("Enter Your MailID");
			a2.setMail(Validation.Validate_MAILID());
			System.out.println("Enter Your Account Opening Balance");
			double accbal = sc.nextDouble();
			a2.setAccount_Balance(accbal);
			a1[i] = a2;

			System.out.println("Your Account Created Successfully");
		}

	}

	@Override
	public void Show_Account_Details() {
		System.out.println("Enter Your Account");
		// int accno = sc.nextInt();
		// if (a.getAccount_No() == accno) {
		// System.out.println(a);

		// } else {
		// System.out.println("Account Doesn't exists");
		// }
		for (Account acn : a1) {
			if (acn != null) {
				System.out.println(acn);
			}
		}

	}

	@Override
	public void Show_Account_Balance() {
		System.out.println("Enter Your Account");
		int accno = sc.nextInt();
		for (Account acn : a1) {
			if(acn!=null && accno==acn.getAccount_No()) {
				System.out.println(acn.getAccount_Balance());
				
			}
			

		}

		// if (a.getAccount_No() == accno) {
		// System.out.println("Current Account Balance=" + " " +
		// a.getAccount_Balance());

		// } else {
		// System.out.println("Account Doesn't Exists");
	}

	@Override
	public void Deposit_Money() {
		System.out.println("Enter Your Account");
		int accno = sc.nextInt();
		for (Account acn : a1) {

			if (acn!=null &&accno == acn.getAccount_No()) {
				System.out.println("Enter Your Amount");
				double d2 = sc.nextDouble();
				double d3 = acn.getAccount_Balance() + d2;
				acn.setAccount_Balance(d3);
				System.out.println("Your Current Account Balance=" + " " + d3);
			}

		}

		// if (accno == a.getAccount_No()) {
		// System.out.println("Enter Your Amount");
		// double d2 = sc.nextDouble();
		// double d3 = a.getAccount_Balance() + d2;
		// a.setAccount_Balance(d3);
		// System.out.println("Your Current Account Balance=" + " " + d3);
		// } else {
		// System.out.println("Account Doesn't Exists");
		// }

	}

	@Override
	public void Withdraw_Money() {
		System.out.println("Enter Your Account");
		int accno = sc.nextInt();
		for (Account acn : a1) {
			if (acn!=null && acn.getAccount_No() == accno) {

				System.out.println("Enter Your Amount");
				double d = sc.nextDouble();
				if (d <= acn.getAccount_Balance()) {
					System.out.println("Transaction Successfull");

					double d1 = acn.getAccount_Balance() - d;
					acn.setAccount_Balance(d1);
					System.out.println("Your Current Balance =" + d1);

				} else {
					System.out.println("Insufficient Balance");
					System.out.println("Please Try Again");
				}
				
				

			} 
			if(acn!=null&&acn.getAccount_Balance()!=accno) {
				System.out.println("Account Doesn't Exists");
				
			}

		}
		//if (a.getAccount_No() == accno) {

		//	System.out.println("Enter Your Amount");
		//	double d = sc.nextDouble();
		//	if (d <= a.getAccount_Balance()) {
			//	System.out.println("Transaction Successfull");

			//	double d1 = a.getAccount_Balance() - d;
			//	a.setAccount_Balance(d1);
				//System.out.println("Your Current Balance =" + d1);

			//} else {
			//	System.out.println("Insufficient Balance");
			//	System.out.println("Please Try Again");
			//}

		//} else {
		//	System.out.println("Account Doesn't Exists");
		//}

	}

	@Override
	public void Update_Account_Details() {
		System.out.println("Enter Your Account");
		boolean b = true;
		int accno = sc.nextInt();
		for (Account a : a1) {
		

				while (b) {
					if (accno == a.getAccount_No()) {
					System.out.println("************************************");
					System.out.println("1:Update Account Name              |");
					System.out.println("2:Update Your Mobile Number        |");
					System.out.println("3:Upadate Your Mail ID             |");
					System.out.println("4:exit                             |");
					System.out.println("************************************");
					System.out.println("Enter Your Choice According to The Given Data");
					int i1 = sc.nextInt();
					// SBI sbi = new SBI();
					switch (i1) {
					case 1:

						// System.out.println("Enter Your New Name"); //String newName = sc.next();
						// this.a.setAccount_Name(newName);
						// System.out.println("Your Updated Name="+" "+newName);
						a.setAccount_Name(SBI.Validate_and_Update_Account_Name());
						break;
					case 2:
						//System.out.println("Enter Your New Mobile Number");
						//long l = sc.nextLong();
						//a.setContact(l);
						//System.out.println("Your Updated Mobile Number =" + " " + l);
						a.setContact(Update_Mobile_Number());

						break;

					case 3:
						// System.out.println("Enter Your New Mail ID");
						// String s1 = sc.next();
						// this.a.setMail(s1);
						// System.out.println("Your Updated Mail ID =" + " " + s1);
						a.setMail(SBI.Update_Mail_ID());
						break;

					case 4:
						b = false;
						break;

					default: {
						System.out.println("You Entered Wrong Number");
						System.out.println("Please Enter Valid Number");
					}

					}
				}else {
					System.out.println("Account Doesn't Exists");
				}
			} 

		}
		}
		//if (accno == a.getAccount_No()) {

			//while (b) {
				//System.out.println("************************************");
				//System.out.println("1:Update Account Name              |");
				//System.out.println("2:Update Your Mobile Number        |");
				//System.out.println("3:Upadate Your Mail ID             |");
				//System.out.println("4:exit                             |");
				//System.out.println("************************************");
				//System.out.println("Enter Your Choice According to The Given Data");

				//int i1 = sc.nextInt();
				// SBI sbi = new SBI();
				//switch (i1) {
				//case 1:

					// System.out.println("Enter Your New Name"); //String newName = sc.next();
					// this.a.setAccount_Name(newName);
					// System.out.println("Your Updated Name="+" "+newName);
					//a.setAccount_Name(SBI.Validate_and_Update_Account_Name());
				//	break;
				//case 2:
				//	System.out.println("Enter Your New Mobile Number");
				// l = sc.nextLong();
					//this.a.setContact(l);
				//	System.out.println("Your Updated Mobile Number =" + " " + l);

					//break;

				//case 3:
					// System.out.println("Enter Your New Mail ID");
					// String s1 = sc.next();
					// this.a.setMail(s1);
					// System.out.println("Your Updated Mail ID =" + " " + s1);
				//	a.setMail(SBI.Update_Mail_ID());
				//	break;

			//	case 4:
				//	b = false;
				//	break;

				//default: {
				//	System.out.println("You Entered Wrong Number");
				//	System.out.println("Please Enter Valid Number");
				//}

				//}
		//	}
		//} else {
		//	System.out.println("Account Doesn't Exists");
		//}

	//}

	public static String Validate_and_Update_Account_Name() {
		System.out.println("Enter Your New Name:-");
		String new_name = sc.next();
		char[] ch1 = new_name.toCharArray();
		boolean flag = true;
		for (int i = 0; i < ch1.length; i++) {
			if (!(new_name.charAt(i) >= 'a' && new_name.charAt(i) <= 'z')
					&& !(new_name.charAt(i) >= 'A' && new_name.charAt(i) <= 'Z')) {
				flag = false;
			}

		}
		if (!flag) {
			System.out.println("Invalid Input");
			System.out.println("Please Use Only Alphabets");
			return Validate_and_Update_Account_Name();
		}

		System.out.println("Your Updated Account Name=" + " " + new_name);

		return new_name;
	}

	public long Update_Mobile_Number() {
		System.out.println("Enter Your New Mobile Number");
		Long l1 = sc.nextLong();
		String s=String.valueOf(l1);
		if(Pattern.matches("[0-9]{10}", s)) {
			
			System.out.println("Your Updated Mobile Number=" + " " + l1);
			return l1;
		}else {
			System.out.println("Invalid Input");
			return Update_Mobile_Number();
		}		
		//System.out.println("Your Updated Mobile Number=" + " " + l1);
		

	}

	public static String Update_Mail_ID() {
		System.out.println("Enter Your New Mail ID");

		String s2 = sc.next();
		if (s2.endsWith("@gmail.com")) {
			System.out.println("Your Updated Mail ID Is =" + " " + s2);
			return s2;

		}else {
			System.out.println("Invalid Input");
			return Update_Mail_ID();
		}

		
	

		

	}

	@Override
	public void Display_Single_Account() {
		System.out.println("Enter Your Account:-");
		long ln = sc.nextLong();
		for (Account account : a1) {
			if (account != null && account.getAccount_No() == ln) {
				System.out.println(account);

			}
		}

	}

}
