package com.Exponent.BankApplication.Model;

public class Account {
	
	private int Account_No;
	private String Account_Name;
	private String Aadhar_Card;
	private String Pancard;
	private long Contact;
	private String mail;
	private double Account_Balance;
	public int getAccount_No() {
		return Account_No;
	}
	public void setAccount_No(int account_No) {
		Account_No = account_No;
	}
	public String getAccount_Name() {
		return Account_Name;
	}
	public void setAccount_Name(String account_Name) {
		Account_Name = account_Name;
	}
	public String getAadhar_Card() {
		return Aadhar_Card;
	}
	public void setAadhar_Card(String aadhar_Card) {
		Aadhar_Card = aadhar_Card;
	}
	public String getPancard() {
		return Pancard;
	}
	public void setPancard(String pancard) {
		Pancard = pancard;
	}
	public long getContact() {
		return Contact;
	}
	public void setContact(long contact) {
		Contact = contact;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public double getAccount_Balance() {
		return Account_Balance;
	}
	public void setAccount_Balance(double account_Balance) {
		Account_Balance = account_Balance;
	}
	@Override
	public String toString() {
		return "Account [Account_No=" + Account_No + ", Account_Name=" + Account_Name + ", Aadhar_Card=" + Aadhar_Card
				+ ", Pancard=" + Pancard + ", Contact=" + Contact + ", mail=" + mail + ", Account_Balance="
				+ Account_Balance + "]";
	}
	

}
