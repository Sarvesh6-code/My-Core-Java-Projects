package com.Exponent.BankApplication.Controller;

import com.Exponent.BankApplication.service.RBI;
import com.Exponent.BankApplication.serviceImpl.*;

import java.util.Scanner;

public class Admin_Controller {
	

	public static void main(String[] args) {

		boolean flag = true;
		Scanner sc = new Scanner(System.in);
		RBI rbi = new SBI();

		while (flag) {

			System.out.println("------WELCOME TO SBI--------");
			System.out.println("****************************");
			System.out.println("1.Create Account           |");
			System.out.println("2.Show Account Details     |");
			System.out.println("3.Show Account Balance     |");
			System.out.println("4.Deposit Money            |");
			System.out.println("5.Withdraw Money           |");
			System.out.println("6.Update Account Details   |");
			System.out.println("7.Display Single Account   |");
			System.out.println("8.Exit                     |");
			System.out.println("****************************");
			System.out.println("Enter your Choice According to The Given Data");

			int i =getvalidchoice();

			switch (i) {
			case 1: 
				rbi.Create_Account();
				break;
			
			case 2: 
				rbi.Show_Account_Details();
				break;
			
			case 3: 
				rbi.Show_Account_Balance();
				break;
			
			case 4: 

				rbi.Deposit_Money();
				break;

			
			case 5: 
				rbi.Withdraw_Money();
				break;
			
			case 6: 
				rbi.Update_Account_Details();
				break;
			
			case 7:
				rbi.Display_Single_Account();
				break;
			case 8: 

				flag = false;
				break;
			

			default:
				System.out.println("You Entered Wrong Number");
				System.out.println("Please Enter Valid Number");
			}

		}

	}
	public static int getvalidchoice() {
		
		Scanner sc = new Scanner(System.in);
		int ch;
		try {
			ch = sc.nextInt();
		} catch (Exception e) {
			System.out.println(e);
			System.out.println("Invalid Input");
			return getvalidchoice();
			
		}
	
		
		
		return ch;
	}


}
