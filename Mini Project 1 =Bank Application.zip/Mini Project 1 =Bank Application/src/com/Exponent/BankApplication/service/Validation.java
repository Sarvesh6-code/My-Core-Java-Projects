package com.Exponent.BankApplication.service;

import java.nio.file.Path;
import java.util.Scanner;
import java.util.regex.Pattern;

import com.Exponent.BankApplication.serviceImpl.SBI;

public class Validation extends SBI {

	static Scanner sc = new Scanner(System.in);

	public static int Validate_Acc_No() {
		int accno = sc.nextInt();

		return accno;
	}

	public static String Validate_Acc_Name() {
		System.out.println("Enter Your Name:-");
		String name = sc.next();
		char[] ch = name.toCharArray();
		boolean flag = true;
		for (int i = 0; i < ch.length; i++) {
			if (!(name.charAt(i) >= 'a' && name.charAt(i) <= 'z')
					&& !(name.charAt(i) >= 'A' && name.charAt(i) <= 'Z')) {

				flag = false;
			}
		}
		if (!flag) {

			System.out.println("Invalid Input");
			System.out.println("Please Use Only Alphabets");
			return Validate_Acc_Name();

		}
		return name;

	}

	public static String Validate_Aadhar_Card() {
		System.out.println("Enter Your Aadhaar Card Number:-");
		String Aadhar_Card = sc.next();
		if (Pattern.matches("[0-9]+", Aadhar_Card) && Aadhar_Card.length() == 12) {
			return Aadhar_Card;
		} else {
			System.out.println("Invalid Input");
			return Validate_Aadhar_Card();
		}

	 }

	public static long Validation_Of_Contact() {
		System.out.println("Enter Your Contact number:-");
		long l = sc.nextLong();
		String l1 = String.valueOf(l);
		boolean b = true;
		if ((l1.startsWith("7")) || (l1.startsWith("8")) || (l1.startsWith("9"))) {

			if (l1.length() == 10) {
				b = false;
			}

		}
		if (b) {
			
			System.out.println("Invalid Contact Number");
			return Validation_Of_Contact();

		}

		return l;
	}

	public static String Validate_Pan_Card() {
		System.out.println("Enter Pan Card Number:-");
		String s1 = sc.next();
		boolean b1 = true;
		if (Pattern.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}", s1)) {

			b1 = false;
		}
		if (b1) {
			System.out.println("Invalid Data");
			System.out.println("Please Try Again");
			return Validate_Pan_Card();
		}

		return s1;
	}

	public static String Validate_MAILID() {
		System.out.println("Enter Your MAIL ID:-");
		String s3 = sc.next();
		if (s3.endsWith("gmail.com")) {
			return s3;

		} else {
			System.out.println("Invalid Input");
			return Validate_MAILID();
		}

	}
}
