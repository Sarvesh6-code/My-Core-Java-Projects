package com.Exponent.BankApplication.service;

public interface RBI {
	
	public void Create_Account();
	public void Show_Account_Details();
	public void Show_Account_Balance();
	public void Deposit_Money();
	public void Withdraw_Money();
	public void Update_Account_Details();
	public void Display_Single_Account();

}
